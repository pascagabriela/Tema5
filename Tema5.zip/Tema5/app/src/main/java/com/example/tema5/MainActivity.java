package com.example.tema5;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    public volatile boolean stopThread = false;
    int random = 0;
    int random1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void generateRandomNumberThread(View view){
        stopThread = false;
        EditText number = findViewById(R.id.number);
        Button check = findViewById(R.id.check);
        TextView you = findViewById(R.id.you);
        check.setClickable(true);
        number.setEnabled(true);
        EditText limit = findViewById(R.id.limit);
        Context context = getApplicationContext();
        CharSequence text = "Please enter a number!";
        int duration = Toast.LENGTH_SHORT;
        if(TextUtils.isEmpty(limit.getText().toString())){
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else {
            new Thread(() -> {
                for (int i = 0; i < 40; i++) {
                    if (stopThread) {
                        return;
                    }
                    random = new Random().nextInt(Integer.parseInt(String.valueOf(limit.getText()))) + 1;
                    Log.d(TAG, "random number " +i+ ": " +random);
                    if(i==9){
                        you.setText("You've lost!");
                        return;
                    }
                    computerGuess(view);
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }


    public void checkNumber(View view){
        EditText number = findViewById(R.id.number);
        TextView you = findViewById(R.id.you);
        TextView computer = findViewById(R.id.computer);
        Button check = findViewById(R.id.check);
        Context context = getApplicationContext();
        CharSequence text = "Please enter a number!";
        int duration = Toast.LENGTH_SHORT;
        if(TextUtils.isEmpty(number.getText().toString())){
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }else if(random==Integer.parseInt(String.valueOf(number.getText()))){
            you.setText("You've guessed!");
            computer.setText("You've lost!");
            stopThread = true;
            check.setClickable(false);
            number.setEnabled(false);
        }else{
            you.setText("Try again!");
        }
    }

    public void computerGuess(View view){
        EditText limit = findViewById(R.id.limit);
        TextView you = findViewById(R.id.you);
        Button check = findViewById(R.id.check);
        EditText number = findViewById(R.id.number);
        TextView computer = findViewById(R.id.computer);
        runOnUiThread(new Thread(() -> {
            random1 = new Random().nextInt(Integer.parseInt(String.valueOf(limit.getText()))) + 1;
            Log.d(TAG, "Computer's number " +random1);
            if(random==random1){
                computer.setText("Winner! The number: " + random1);
                you.setText("Looser!");
                stopThread = true;
                check.setClickable(false);
                number.setEnabled(false);
            }else{
                computer.setText("Try again!");
            }
        })
        );
    }


}